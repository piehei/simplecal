/**
 * Created by pate on 4.12.2015.
 */


Date.prototype.getWeekNumber = function () {
    var d = new Date(+this);
    d.setHours(0, 0, 0);
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    return Math.ceil((((d - new Date(d.getFullYear(), 0, 1)) / 8.64e7) + 1) / 7);
};
Date.prototype.getLastDay = function () {
    var nyt_str = new Date(this.getFullYear(), this.getMonth()+1, 0);
    return nyt_str.getDate();
};

function getISOWeeks(y) {
    var d,
        isLeap;

    d = new Date(y, 0, 1);
    isLeap = new Date(y, 1, 29).getMonth() === 1;

    //check for a Jan 1 that's a Thursday or a leap year that has a
    //Wednesday jan 1. Otherwise it's 52
    return d.getDay() === 4 || isLeap && d.getDay() === 3 ? 53 : 52
}

function getDateOfISOWeek(w, y) {
    var simple = new Date(y, 0, 1 + (w - 1) * 7);
    var dow = simple.getDay();
    var ISOweekStart = simple;
    if (dow <= 4)
        ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
    else
        ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
    return ISOweekStart;
};
function raktivoi(datu) {
    var rakki = new Ractive({
        el: "#root",
        template: "#template_calendar",
        data: datu
    });
};
function new_day () {};

function give (given_date, how_many_weeks) {


    var today = given_date;
    var this_month_first_day = new Date(today.getFullYear(), today.getMonth(), 1);
    var this_month_last_day = new Date(today.getFullYear(), today.getMonth(), today.getLastDay());
    var this_month = today.getMonth();

    var this_month_last_day_object = new Date(today.getFullYear(), today.getMonth(), this_month_last_day.getDate());
    var this_month_last_day_position = this_month_last_day_object.getDay();
    var this_month_last_day_week = this_month_last_day_object.getWeekNumber();


    var this_month_first_day_object = new Date(today.getFullYear(), today.getMonth(), this_month_first_day.getDate());
    var this_month_first_day_position = this_month_first_day_object.getDay();
    var this_month_first_day_week = this_month_first_day_object.getWeekNumber();

    console.log("First of this month: ", this_month_first_day, " + position: ", this_month_first_day_position);
    console.log("Last of this month: ", this_month_last_day, " + position: ", this_month_last_day_position);
    console.log("This month: ", this_month);

    var objects_inner = {};
    var rolling_day = 1;
    var this_week = today.getWeekNumber();
    var cal_week_start = this_week - 3;
    var cal_week_end = this_week + 3;
    var cal_week_year = today.getFullYear();
    var cal_week_year_total_weeks = getISOWeeks(cal_week_year);

    var objects = {};
    objects["weeks"] = {};

    var object_roller = 0;
    for (var i = cal_week_start; i < cal_week_end; i += 1) {

        var loop_week_first_day;
        var loop_week_number;
        var loop_year;

        if (i < cal_week_year_total_weeks + 1) {
            loop_week_number = i;
            loop_year = cal_week_year;
            loop_week_first_day = getDateOfISOWeek(loop_week_number, loop_year);
        }
        else {
            loop_week_number = i - cal_week_year_total_weeks;
            loop_year = cal_week_year + 1;
            loop_week_first_day = getDateOfISOWeek(loop_week_number, loop_year);
        }
        console.log("loop week: ", loop_week_number);
        console.log("loop week first day: ", loop_week_first_day);

        var loop_obj = {};
        var loop_array = [];
        for (var d = 0; d < 7; d += 1) {
            var next_day = getDateOfISOWeek(loop_week_number, loop_year);
            next_day.setDate(next_day.getDate() + d);
            loop_array.push(next_day.getDate());
        }

        objects["weeks"][object_roller] = { "week_number": loop_week_number,
                                            "days": loop_array};
        object_roller += 1;
    }


    console.log(objects);
    return objects;

    }

(function start_app () {

    var gog = new Date();
    var gog2 = new Date(2016, 1, 20);

    var ob = give(gog, 6);
    raktivoi(ob);

}());